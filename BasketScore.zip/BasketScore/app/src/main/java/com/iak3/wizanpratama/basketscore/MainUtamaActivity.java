package com.iak3.wizanpratama.basketscore;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


    @SuppressLint("Registered")
    public class MainUtamaActivity extends Activity {
        int scoreTeamA, scoreTeamB = 0;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_utama);

            Intent i = this.getIntent();
            String namaA = i.getStringExtra("namaA");
            String namaB = i.getStringExtra("namaB");

            TextView TnamaA = findViewById(R.id.namaA);
            TextView TnamaB = findViewById(R.id.namaB);

            TnamaA.setText(namaA);
            TnamaB.setText(namaB);


        }

        public void displayForTeamA(int score) {
            TextView scoreView = findViewById(R.id.team_a_score);
            scoreView.setText(String.valueOf(score));
      /*
      Menampilkan score Team A di dalam TextView yang di tampilkan
      Menset nilai score yang bertipe data integer

       */

        }

        public void tigapointa(View v) {
            scoreTeamA = scoreTeamA + 3;
            displayForTeamA(scoreTeamA);
            //Menambah Point Team A 3
        }

        public void duapointa(View v) {
            scoreTeamA = scoreTeamA + 2;
            displayForTeamA(scoreTeamA);
            //Menambah Point Team A 2
        }

        public void satupointa(View v) {
            scoreTeamA = scoreTeamA + 1;
            displayForTeamA(scoreTeamA);
            //Menambah Point Team A 1
        }

        public void displayForTeamB(int score) {
            TextView scoreView = findViewById(R.id.team_b_score);
            scoreView.setText(String.valueOf(score));
             /*
      Menampilkan score Team B di dalam TextView yang di tampilkan
      Menset nilai score yang bertipe data integer
       */
        }

        public void tigapointb(View v) {
            scoreTeamB = scoreTeamB + 3;
            displayForTeamB(scoreTeamB);
            // Menambah Point Team B 3
        }

        public void duapointb(View v) {
            scoreTeamB = scoreTeamB + 2;
            displayForTeamB(scoreTeamB);
            // Menambah Point Team B 2
        }

        public void satupointb(View v) {
            scoreTeamB = scoreTeamB + 1;
            displayForTeamB(scoreTeamB);
            // Menambah Point Team B 1
        }

        public void resetPoint(View v) {
            scoreTeamA = 0;
            scoreTeamB = 0;
            displayForTeamA(scoreTeamA);
            displayForTeamB(scoreTeamB);
            //Mereset point Team A ke 0


        }

    }